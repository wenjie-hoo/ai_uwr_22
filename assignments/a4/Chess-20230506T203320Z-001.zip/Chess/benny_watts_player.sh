#!/bin/bash

python3 benny_watts.py
