#!/bin/bash

python3 chess_random.py
