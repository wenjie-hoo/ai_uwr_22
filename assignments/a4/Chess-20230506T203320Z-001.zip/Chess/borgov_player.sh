#!/bin/bash

python3 borgov.py
