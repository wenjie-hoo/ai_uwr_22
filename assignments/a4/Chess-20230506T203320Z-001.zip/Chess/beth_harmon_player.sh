#!/bin/bash

python3 beth_harmon.py
